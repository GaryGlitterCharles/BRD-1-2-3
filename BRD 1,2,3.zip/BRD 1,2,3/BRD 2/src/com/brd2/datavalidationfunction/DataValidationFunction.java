package com.brd2.datavalidationfunction;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataValidationFunction
{
	static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");

	public static void main(String[] args)
	{ // Data Type Validation
		// System.out.println(validateDataType('c'));
		// Data length
		// System.out.println(validateLength("18910", 2));
		// Special Characters
		// System.out.println(validateNoSpecialCharacters("gary"));
		// Domain Value
//		List<String> list = new ArrayList<>();
//		list.add("Monday");
//		list.add("Tuesday");
//		list.add("Wednesday");
//		list.add("Thrusday");
//		list.add("Friday");
//		list.add("Saturday");
//		list.add("Sunday");
		// System.out.println(validateDomainValues("Tuesday",list ));
		// Format Validation
		System.out.println(validateDateFormat("3/30/1996", simpleDateFormat));
		// Validate E-mail
		// System.out.println(validateEmail("garycharles@nucleusSoftwarecom"));
	}

	public static Boolean validateDataType(Object numeric)
	{

		if (numeric.getClass().getSimpleName().equals("Integer"))
		{
			return true;
		} else if (numeric.getClass().getSimpleName().equals("String"))
		{
			return true;
		} else if (numeric.getClass().getSimpleName().equals("Double"))
		{
			return true;
		} else if (numeric.getClass().getSimpleName().equals("Character"))
		{
			return true;
		} else if (numeric.getClass().getSimpleName().equals("Boolean"))
		{
			return true;
		}
		return false;

	}

	public static Boolean validateLength(String field, int size)
	{

		if (field.length() <= size)
		{
			return true;
		}
		return false;

	}

	public static Boolean validateNoSpecialCharacters(String field)
	{
		if (field.contains("#") || field.contains("@") || field.contains("$") || field.contains("%")
				|| field.contains("^"))
		{
			return false;
		}
		return true;

	}

	public static Boolean validateDomainValues(String field, List<String> list)
	{

		if (list.contains(field))
		{

			return true;
		}
		return false;

	}

	public static Boolean validateDateFormat(String field, SimpleDateFormat dates)
	{
		dates.setLenient(false);

		try
		{

			dates.parse(field);
			return true;
		} catch (ParseException e)
		{
			return false;
		}

	}

	public static Boolean validateEmail(String field)
	{
		if (field.contains("@") || field.contains("."))
		{
			if (!field.contains(" "))
			{
				return true;
			}

		}

		return false;

	}

}
