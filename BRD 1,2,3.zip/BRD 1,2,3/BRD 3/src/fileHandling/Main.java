package fileHandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import fileHandling.Customers;
import fileHandling.NewConnection;

public class Main
{
	static List<String> list = new ArrayList<>();

	public static void main(String[] args) 
	{
		File file;
		FileReader filereader;
		BufferedReader bufferedReader;
		try
		{
			String  fileExt= "D://File1.txt";
			file = new File(fileExt);
			filereader = new FileReader(file);
			bufferedReader = new BufferedReader(filereader);
			if (!fileExt.endsWith(".txt")) {
				System.exit(0);
			}

			String files;
			try
			{
				while ((files = bufferedReader.readLine()) != null )
				{
					files += "~";
					list.add(files);

				}

			}
			
			catch (IOException ioException)
			{
				System.out.println("Error: "+ioException);
			}
			System.out.println(list.size());

			String s = null;
			String[] records;
			Customers customer = new Customers();
			int count = 0;
			for (int i = 0; i < list.size(); i++)
			{
				s = list.get(i);
				records = s.split("(?<=~)");
				customer.setCustomerID(count += 1);
				customer.setCustomerCode(records[0].substring(0, records[0].lastIndexOf("~")));
				customer.setCustomerName(records[1].substring(0, records[1].lastIndexOf("~")));
				customer.setCustomerAddress1(records[2].substring(0, records[2].lastIndexOf("~")));
				customer.setCustomerAddress2(records[3].substring(0, records[3].lastIndexOf("~")));
				customer.setCustomerPinCode(records[4].substring(0, records[4].lastIndexOf("~")));
				customer.setEmailAddress(records[5].substring(0, records[5].lastIndexOf("~")));
				customer.setContactNumber(records[6].substring(0, records[6].lastIndexOf("~")));
				customer.setPrimaryContactPerson(records[7].substring(0, records[7].lastIndexOf("~")));
				customer.setRecordStatus(records[8].substring(0, records[8].lastIndexOf("~")));
				customer.setActiveInactiveFlag(records[9].substring(0, records[9].lastIndexOf("~")));
				customer.setCreateDate(records[10].substring(0, records[10].lastIndexOf("~")));
				customer.setCreatedBy(records[11].substring(0, records[11].lastIndexOf("~")));
				customer.setModifiedDate(records[12].substring(0, records[12].lastIndexOf("~")));
				customer.setModifiedBy(records[13].substring(0, records[13].lastIndexOf("~")));
				customer.setAuthorizedDate(records[14].substring(0, records[14].lastIndexOf("~")));
				customer.setAuthorizedBy(records[15].substring(0, records[15].lastIndexOf("~")));
				try
				{
						if(validator(customer)==true)
						{
							NewConnection.databaseMethod(customer);
							
						}
						else 
						{
							System.out.println("missing field");
						}
				
				}
				catch (SQLException sqlException)
				{
					System.out.println("Error: "+sqlException);
				}

			}

		} catch (FileNotFoundException fileNotFoundException)
		{
			System.out.println("Error: "+fileNotFoundException);
		}

	}

	public static Boolean validator(Customers customer)
	{

		Boolean pincodeResult = PincodeValidation( customer.getCustomerPinCode());
		Boolean EmailResult = EmailValidation(customer.getEmailAddress());
		Boolean RecordStatusResult = RecordStatusValidation(customer.getRecordStatus());
		Boolean ActiveInactiveResult = ActiveInactiveFlag(customer.getActiveInactiveFlag());
		Boolean customerNameResult = customerNameValidate(customer.getCustomerName());

		if (pincodeResult && EmailResult && RecordStatusResult && ActiveInactiveResult&&customerNameResult)
		{
			return true;
		} 
		return false;
		
	}


	public static Boolean PincodeValidation(String string)
	{
		if (string.length() == 6)
		{
			return true;
		}
		return false;
	}

	public static Boolean customerNameValidate(String string)
	{
		Pattern p = Pattern.compile("[^A-Za-z0-9]");
		if (p.matcher(string).find())
		{
			return true;
		}
		return false;
	}

	public static boolean EmailValidation(String string)
	{
		if (string.contains("@") || string.contains("."))
		{
			if (!string.contains(" "))
			{
				return true;
			}
		}
		return false;

	}

	public static boolean RecordStatusValidation(String string)
	{
		if (string.contains("N") || string.contains("M") || string.contains("D") || string.contains("A")
				|| string.contains("R"))
		{
			return true;
		}
		return false;

	}

	public static boolean ActiveInactiveFlag(String string)
	{
		if (string.contains("A") || string.contains("I"))
		{
			return true;
		}
		return false;
	}

}