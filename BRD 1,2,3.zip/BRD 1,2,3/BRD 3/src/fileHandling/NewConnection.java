package fileHandling;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



public class NewConnection
{
	 static Connection connection = null;
	static
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");	
		} 
		catch (ClassNotFoundException classNotFoundException)
		{
			System.out.println("Error: "+classNotFoundException);
		}
		catch (SQLException sqlException) 
		{
			System.out.println("Error: "+sqlException);
		}
	}
	PreparedStatement preparedstatement = null;



	public static void databaseMethod(Customers customer) throws SQLException
	{
		
		PreparedStatement preparedstatement =connection.prepareStatement("insert into user_details_form values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		preparedstatement.setInt(1, customer.getCustomerID());
		preparedstatement.setString(2, customer.getCustomerCode());
		preparedstatement.setString(3, customer.getCustomerName());
		preparedstatement.setString(4, customer.getCustomerAddress1());
		preparedstatement.setString(5, customer.getCustomerAddress2());
		preparedstatement.setString(6, customer.getCustomerPinCode());
		preparedstatement.setString(7, customer.getEmailAddress());
		preparedstatement.setString(8, customer.getContactNumber());
		preparedstatement.setString(9, customer.getPrimaryContactPerson());
		preparedstatement.setString(10, customer.getRecordStatus());
		preparedstatement.setString(11, customer.getActiveInactiveFlag());
		preparedstatement.setString(12, customer.getCreateDate());
		preparedstatement.setString(13, customer.getCreatedBy());
		preparedstatement.setString(14, customer.getModifiedDate());
		preparedstatement.setString(15, customer.getModifiedBy());
		preparedstatement.setString(16, customer.getAuthorizedDate());
		preparedstatement.setString(17, customer.getAuthorizedBy());
		
		preparedstatement.executeUpdate();
		

	}
	public static void name()
	{
		try
		{
			PreparedStatement preparedstatement =connection.prepareStatement("TRUNCATE TABLE user_details_form");
			preparedstatement.executeUpdate();
			connection.close();
		} catch (SQLException e)
		{
			System.out.println(e);
		}
	}

}
