
import java.text.DecimalFormat;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class EmiCalculator
{

	public static List<String> list = new ArrayList<>();

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the loan Amount: ");
		double loanAmount = sc.nextInt();
		System.out.println("Enter the Rate Of Interest: ");
		double rateOfInterest = sc.nextDouble();
		double rateOfInPercentage = rateOfInterest / 100;
		int tenure=0;
		int numOfInstalments=0;
		
		try
		{
				System.out.println("Enter the Tenure: ");
				tenure = sc.nextInt();
				if(tenure <0)
				{
					throw new InputMismatchException("YOU HAVE ENTERED NEGATIVE NUMBER!!!!!!");
				}
			
		}
		catch(InputMismatchException e)
		{
			System.out.println(e.getMessage());
			while(tenure < 0)
			{
				
				System.out.println("Enter the positive number");
				tenure = sc.nextInt();
			}
		}
		
		try
		{
			System.out.println("Number of Installments in a Year: ");
			numOfInstalments = sc.nextInt();

			if(numOfInstalments < 12 || numOfInstalments >12)
						{
							throw new InputMismatchException("YOU HAVE ENTERED NUMBER LESS THAN 12!!!!");
						}
			
		}
		catch(InputMismatchException e)
		{
			System.out.println(e.getMessage());
			while(numOfInstalments < 12 || numOfInstalments >12 )
			{
				
				System.out.println("Enter the number 12");
				numOfInstalments = sc.nextInt();
			}
		}
		
		System.out.format("%-15s %-15s %-15s %-15s %-15s\n","Serial number", "Loan Amount", "Interest", "Principal", "EMI");
		result(loanAmount, rateOfInPercentage, tenure, numOfInstalments);
		System.out.println("Enter type");
		int fromUser = sc.nextInt();
		System.out.println(list.get(fromUser));
		
	}

	public static double result(double loanAmount, double rateOfInPercentage, int tenure, int numOfInstalments)
	{
		for (int i = 0; i <12; i++)
		{

			loanAmount = results(i,loanAmount, rateOfInPercentage, tenure, numOfInstalments);

		}
		return loanAmount;

	}

	static double emi = 0.0;
	static boolean emiCalculation = true;
	public static double results(int count,double loanAmount, double rateOfInPercentage, int tenure, int numOfInstalments)
	{
		double numerator = loanAmount * (rateOfInPercentage / numOfInstalments);
		double deno1 = 1 + (rateOfInPercentage / numOfInstalments);
		double deno2 = 1 / (Math.pow(deno1, tenure));

		double deominator = 1 - deno2;
		if (emiCalculation)
		{
			emi = numerator / deominator;
			emiCalculation = false;
		}

		double Pn = emi - numerator;
		double Opn = loanAmount - Pn;
		DecimalFormat formatter = new DecimalFormat("0.00");
		DecimalFormat formatter1 = new DecimalFormat("0");
		
		
		String v = ("Serial number: "+formatter1.format(count)+", Loan Amount: " + formatter.format(loanAmount) + ", Interest: " + formatter.format(numerator)
				+ ", Principal: " + formatter.format(Pn) + ", EMI: " + formatter.format(emi));
		list.add(v);

		System.out.format("%-15s %-15s %-15s %-15s %-15s\n",formatter1.format(count),formatter.format(loanAmount), formatter.format(numerator),
				formatter.format(Pn), formatter.format(emi));
		return Opn;
	}

}
