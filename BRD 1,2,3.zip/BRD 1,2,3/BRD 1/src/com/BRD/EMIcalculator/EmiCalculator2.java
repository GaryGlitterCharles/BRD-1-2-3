
package com.BRD.EMIcalculator;

import java.text.DecimalFormat;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class EmiCalculator2
{
	static double emi = 0.0;

	static boolean emiFlag = true;

	public static List<String> emiRecords = new ArrayList<>();

	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the loan Amount: ");
		double loanAmount = scanner.nextInt();
		System.out.println("Enter the Rate Of Interest: ");
		double rateOfInterest = scanner.nextDouble();
		double rateOfInPercentage = rateOfInterest / 100;
		int tenure = 0;
		int numOfInstalments = 0;
		try
		{
			System.out.println("Enter the Tenure: ");
			tenure = scanner.nextInt();
			if (tenure < 0)
			{
				throw new InputMismatchException("YOU HAVE ENTERED NEGATIVE NUMBER!!!!!!");
			}

		} catch (InputMismatchException inputMismatchException)
		{
			System.out.println("Error: " + inputMismatchException.getMessage());
			while (tenure < 0)
			{

				System.out.println("Enter the positive number: ");
				tenure = scanner.nextInt();
			}
		}

		try
		{
			System.out.println("Number of Installments in a Year: ");
			numOfInstalments = scanner.nextInt();

			if (numOfInstalments > tenure)
			{
				throw new InputMismatchException("enter the installment less than tenure: " + tenure);
			}

		} catch (InputMismatchException inputMismatchException)
		{
			System.out.println("Error: " + inputMismatchException.getMessage());
			while (numOfInstalments > tenure)
			{

				System.out.println("enter the installment less than tenure: " + tenure);
				numOfInstalments = scanner.nextInt();
			}
		}



		for (int i = 0; i < numOfInstalments; i++)
		{

			loanAmount = calculateEMI(i, loanAmount, rateOfInPercentage, tenure, numOfInstalments);

		}

	}

	public static double calculateEMI(int count, double loanAmount, double rateOfInPercentage, int tenure,
			int numOfInstalments) 
	{
		double numerator = loanAmount * (rateOfInPercentage / numOfInstalments);
		double deno1 = 1 + (rateOfInPercentage / numOfInstalments);
		double deno2 = 1 / (Math.pow(deno1, tenure));

		double deominator = 1 - deno2;
		if (emiFlag)
		{
			emi = numerator / deominator;
			emiFlag = false;
		}

		double Pn = emi - numerator;
		double Opn = loanAmount - Pn;
		DecimalFormat formatter = new DecimalFormat("0.00");
		DecimalFormat formatter1 = new DecimalFormat("0");

		String v = ("Serial number: " + formatter1.format(count) + ", Loan Amount: " + formatter.format(loanAmount)
				+ ", Interest: " + formatter.format(numerator) + ", Principal: " + formatter.format(Pn) + ", EMI: "
				+ formatter.format(emi));
		emiRecords.add(v);

		System.out.format("%-15s %-15s %-15s %-15s %-15s\n", formatter1.format(count), formatter.format(loanAmount),
				formatter.format(numerator), formatter.format(Pn), formatter.format(emi));
		return Opn;
	}

}
